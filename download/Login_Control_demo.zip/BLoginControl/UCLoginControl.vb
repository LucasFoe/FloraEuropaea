Option Explicit On 
Imports System
Imports System.Data
Imports System.Data.SqlClient

Public Class UCLoginControl
    Inherits System.Windows.Forms.UserControl

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()
        Me.TxtUsername.Focus()
        'Add any initialization after the InitializeComponent() call

    End Sub

    'UserControl overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents btnlogin As System.Windows.Forms.Button
    Friend WithEvents btnCancel As System.Windows.Forms.Button
    Friend WithEvents lblusername As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents TxtUsername As System.Windows.Forms.TextBox
    Friend WithEvents TxtPassword As System.Windows.Forms.TextBox
    Friend WithEvents lnkmailid As System.Windows.Forms.LinkLabel
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.btnlogin = New System.Windows.Forms.Button
        Me.btnCancel = New System.Windows.Forms.Button
        Me.lblusername = New System.Windows.Forms.Label
        Me.Label2 = New System.Windows.Forms.Label
        Me.TxtUsername = New System.Windows.Forms.TextBox
        Me.TxtPassword = New System.Windows.Forms.TextBox
        Me.lnkmailid = New System.Windows.Forms.LinkLabel
        Me.SuspendLayout()
        '
        'btnlogin
        '
        Me.btnlogin.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnlogin.Location = New System.Drawing.Point(56, 96)
        Me.btnlogin.Name = "btnlogin"
        Me.btnlogin.TabIndex = 2
        Me.btnlogin.Text = "Log In"
        '
        'btnCancel
        '
        Me.btnCancel.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnCancel.Location = New System.Drawing.Point(176, 96)
        Me.btnCancel.Name = "btnCancel"
        Me.btnCancel.TabIndex = 3
        Me.btnCancel.Text = "Cancel"
        '
        'lblusername
        '
        Me.lblusername.Location = New System.Drawing.Point(24, 24)
        Me.lblusername.Name = "lblusername"
        Me.lblusername.TabIndex = 2
        Me.lblusername.Text = "User Name"
        Me.lblusername.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label2
        '
        Me.Label2.Location = New System.Drawing.Point(24, 56)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(96, 23)
        Me.Label2.TabIndex = 3
        Me.Label2.Text = "Password"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'TxtUsername
        '
        Me.TxtUsername.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TxtUsername.Location = New System.Drawing.Point(160, 24)
        Me.TxtUsername.MaxLength = 50
        Me.TxtUsername.Name = "TxtUsername"
        Me.TxtUsername.Size = New System.Drawing.Size(136, 21)
        Me.TxtUsername.TabIndex = 0
        Me.TxtUsername.Text = ""
        '
        'TxtPassword
        '
        Me.TxtPassword.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TxtPassword.Location = New System.Drawing.Point(160, 56)
        Me.TxtPassword.MaxLength = 12
        Me.TxtPassword.Name = "TxtPassword"
        Me.TxtPassword.Size = New System.Drawing.Size(136, 21)
        Me.TxtPassword.TabIndex = 1
        Me.TxtPassword.Text = ""
        '
        'lnkmailid
        '
        Me.lnkmailid.Location = New System.Drawing.Point(112, 0)
        Me.lnkmailid.Name = "lnkmailid"
        Me.lnkmailid.Size = New System.Drawing.Size(128, 23)
        Me.lnkmailid.TabIndex = 6
        Me.lnkmailid.TabStop = True
        Me.lnkmailid.Text = "Done by Barathan.K"
        Me.lnkmailid.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.lnkmailid.Visible = False
        '
        'UCLoginControl
        '
        Me.Controls.Add(Me.lnkmailid)
        Me.Controls.Add(Me.TxtPassword)
        Me.Controls.Add(Me.TxtUsername)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.lblusername)
        Me.Controls.Add(Me.btnCancel)
        Me.Controls.Add(Me.btnlogin)
        Me.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Name = "UCLoginControl"
        Me.Size = New System.Drawing.Size(312, 136)
        Me.ResumeLayout(False)

    End Sub

#End Region

#Region " Enum Declarations "
    Public Enum QueryType
        StoredProcedure
        SelectQuery
    End Enum
    Public Enum ButtonStyles
        WindowsFlat
        XpStyle
    End Enum
#End Region

#Region " Variable Declarations "
    Dim _SelectionMode As String
    Dim _SelectQuery As String = ""
    Dim _UserIdColumnName As String = ""
    Dim _UserPasswordColumnName As String = ""
    Dim _TableName As String = ""
    Dim _StoredProcedureName As String = ""
    Dim _UserIdParameter As String = ""
    Dim _UserPasswordParameter As String = ""
    Dim _ConnectionString As String = "None"
    Private Const MsgTitle = "Barathan Login Control"
#End Region

#Region " Properties "
    Public Property SelectionMode() As QueryType
        Get
            Return _SelectionMode
        End Get
        Set(ByVal Value As QueryType)
            _SelectionMode = Value
        End Set
    End Property
    Public Property ConnectionString() As String
        Get
            Return _ConnectionString
        End Get
        Set(ByVal Value As String)
            _ConnectionString = Value
        End Set
    End Property

#Region " If Selection Mode is Select Query "
    Public Property SelectQuery() As String
        Get
            Return _SelectQuery
        End Get
        Set(ByVal Value As String)
            _SelectQuery = Value
        End Set
    End Property
    Public Property UserIdColumnName() As String
        Get
            Return _UserIdColumnName
        End Get
        Set(ByVal Value As String)
            _UserIdColumnName = Value
        End Set
    End Property
    Public Property UserPasswordColumnName() As String
        Get
            Return _UserPasswordColumnName
        End Get
        Set(ByVal Value As String)
            _UserPasswordColumnName = Value
        End Set
    End Property
    Public Property TableName() As String
        Get
            Return _TableName
        End Get
        Set(ByVal Value As String)
            _TableName = Value
        End Set
    End Property
#End Region

#Region " if Selection Mode is StoredProcedure "
    Public Property StoredProcedureName() As String
        Get
            Return _StoredProcedureName
        End Get
        Set(ByVal Value As String)
            _StoredProcedureName = Value
        End Set
    End Property
    Public Property UserIdParameter() As String
        Get
            Return _UserIdParameter
        End Get
        Set(ByVal Value As String)
            _UserIdParameter = Value
        End Set
    End Property
    Public Property UserPasswordParameter() As String
        Get
            Return _UserPasswordParameter
        End Get
        Set(ByVal Value As String)
            _UserPasswordParameter = Value
        End Set
    End Property
#End Region

#End Region

#Region " Code for Creating Events "
    Public Event OnUserExists(ByVal drUserInfo As DataRow)
    Public Event OnUserInvalid()
#End Region

#Region " Code for Checking the Properties "
    Private Function CheckProperties() As Boolean
        Try
            If Me.SelectionMode = QueryType.SelectQuery Then
                If Me.ConnectionString = "" Or UCase(Me.ConnectionString) = UCase("None") Then
                    MessageBox.Show("You Must Specify the Connection String", "Barathan Login Control", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                    Return False
                End If
                If Me.UserIdColumnName = "" Then
                    MessageBox.Show("You Must Specify the UserId ColumnName", "Barathan Login Control", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                    Return False
                End If
                If Me.UserPasswordColumnName = "" Then
                    MessageBox.Show("You Must Specify the User Password ColumnName", "Barathan Login Control", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                    Return False
                End If
                If Me.TableName = "" Then
                    MessageBox.Show("You Must Specify the Table Name", "Barathan Login Control", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                    Return False
                End If
            ElseIf Me.SelectionMode = QueryType.StoredProcedure Then
                If Me.ConnectionString = "" Or UCase(Me.ConnectionString) = UCase("None") Then
                    MessageBox.Show("You Must Specify the Connection String", "Barathan Login Control", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                    Return False
                End If
                If Me.StoredProcedureName = "" Then
                    MessageBox.Show("You Must Specify the Storedprocedure Name", "Barathan Login Control", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                    Return False
                End If
                If Me.UserIdParameter = "" Then
                    MessageBox.Show("You Must Specify the User Id Parameter Name", "Barathan Login Control", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                    Return False
                End If
                If Me.UserPasswordParameter = "" Then
                    MessageBox.Show("You Must Specify the User Password Parameter Name", "Barathan Login Control", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                    Return False
                End If
            End If
            Return True
        Catch ex As Exception

        End Try
    End Function
#End Region

#Region " Code for Checking the Text Boxes "
    Private Function CheckTextBoxes() As Boolean
        Try
            If Me.TxtUsername.Text = "" Then
                MessageBox.Show("User Name is Required", "Barathan Login Control", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                Me.TxtUsername.Focus()
                Return False
            End If
            If Me.TxtPassword.Text = "" Then
                MessageBox.Show("User Password is Required", "Barathan Login Control", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                Me.TxtPassword.Focus()
                Return False
            End If
            Return True
        Catch ex As Exception
            MessageBox.Show("Error while Validating Text boxes", MsgTitle, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        End Try
    End Function
#End Region

#Region " Methods to Check the User name and Password "

    ' Function Name    : CheckLogin()
    ' 
    ' Author           : K.Barathan
    ' 
    ' Input            : N/A
    ' 
    ' Output           : Boolean        
    ' 
    ' Logic            : This is the Function that will be invoked to check the database

    Private Function CheckLogin() As Boolean
        Try
            If Me.SelectionMode = QueryType.SelectQuery Then
                If Me.ExecuteSelectQuery = False Then
                    RaiseEvent OnUserInvalid()
                End If
            Else
                If Me.ExecuteStoredProcedure = False Then
                    RaiseEvent OnUserInvalid()
                End If
            End If
        Catch ex As Exception
            Throw ex
        End Try
    End Function

    ' Function Name    : ExecuteSelectQuery()
    ' 
    ' Author           : K.Barathan
    ' 
    ' Input            : N/A
    ' 
    ' Output           : Boolean Value
    ' 
    ' Logic            : This Will Execute the Select Query with the user id and password column with values
    '                    and return true if user exists and false when not exists

    Private Function ExecuteSelectQuery() As Boolean
        Try
            Dim StrQuery As String
            Dim dsUser As New DataSet
            StrQuery = "Select " & Me.UserIdColumnName & " , " & Me.UserPasswordColumnName & " From " _
                    & Me.TableName & " Where " & Me.UserIdColumnName & " = '" & Me.TxtUsername.Text.ToString().Trim & _
                    "' And " & Me.UserPasswordColumnName & "= '" & Me.TxtPassword.Text.ToString().Trim & "'"
            Dim Conn As New SqlConnection(Me.ConnectionString)
            Conn.Open()
            Dim myCmd As New SqlCommand(StrQuery, Conn)
            myCmd.CommandType = CommandType.Text
            Dim myDa As New SqlDataAdapter(myCmd)
            myDa.Fill(dsUser)
            Conn.Close()
            If dsUser.Tables(0).Rows.Count > 0 Then
                RaiseEvent OnUserExists(dsUser.Tables(0).Rows(0))
                Return True
            Else
                Return False
            End If
        Catch ex As Exception
            MessageBox.Show("Error While Executing the Select Statements", "Select Statement Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            Return False
        End Try
    End Function

    ' Function Name    : ExecuteStoredProcedure()
    ' 
    ' Author           : K.Barathan
    ' 
    ' Input            : N/A
    ' 
    ' Output           : Boolean Value
    ' 
    ' Logic            : This Will Execute the specified Stored Procedure with the user id and password parameters
    '                    and return true if user exists and false when not exists

    Private Function ExecuteStoredProcedure() As Boolean
        Try
            Dim dsUser As New DataSet
            Dim Conn As New SqlConnection(Me.ConnectionString)
            Conn.Open()
            Dim myCmd As New SqlCommand(Me.StoredProcedureName, Conn)
            Dim PrmUserId As SqlParameter = myCmd.Parameters.Add(Me.UserIdParameter, Me.TxtUsername.Text.ToString().Trim())
            Dim PrmPassword As SqlParameter = myCmd.Parameters.Add(Me.UserPasswordParameter, Me.TxtPassword.Text.ToString.Trim())
            myCmd.CommandType = CommandType.StoredProcedure
            Dim MyDa As New SqlDataAdapter(myCmd)
            MyDa.Fill(dsUser)
            Conn.Close()
            If dsUser.Tables(0).Rows.Count > 0 Then
                RaiseEvent OnUserExists(dsUser.Tables(0).Rows(0))
                Return True
            Else
                Return False
            End If
        Catch ex As Exception
            MessageBox.Show("Error While Executing the Stored Procedures", "Executing Stored Procedure Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            Return False
        End Try
    End Function
#End Region

#Region " Code for Login Button "
    Private Sub btnlogin_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnlogin.Click
        Try
            If Me.CheckProperties = True Then
                If Me.CheckTextBoxes = True Then
                    Me.CheckLogin()
                End If
            Else
                Me.Dispose()
                Application.Exit()
            End If
        Catch ex As Exception

        End Try
    End Sub
#End Region

#Region " Code for Cancel Button "
    Private Sub btnCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCancel.Click
        Try
            Me.ParentForm.Close()
        Catch ex As Exception

        End Try
    End Sub
#End Region

#Region " Code for Key Up Events "
    Private Sub TxtUsername_KeyUp(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles TxtUsername.KeyUp
        Try
            If e.KeyCode = Keys.Enter Then
                Me.TxtPassword.Focus()
            End If
        Catch ex As Exception

        End Try
    End Sub
    Private Sub TxtPassword_KeyUp(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles TxtPassword.KeyUp
        Try
            If e.KeyCode = Keys.Enter Then
                Me.btnlogin_Click(sender, e.Empty)
            End If
        Catch ex As Exception

        End Try
    End Sub
#End Region

#Region " Code for Mailing Barathan "
    Private Sub lnkmailid_LinkClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles lnkmailid.LinkClicked
        Try
            System.Diagnostics.Process.Start("MailTo:kbarathan@gmail.com")
        Catch ex As Exception

        End Try
    End Sub
#End Region

End Class
