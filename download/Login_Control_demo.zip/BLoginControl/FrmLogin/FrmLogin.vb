Public Class FrmLogin
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()
        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents UcLogin As BLoginControl.UCLoginControl
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.UcLogin = New BLoginControl.UCLoginControl
        Me.SuspendLayout()
        '
        'UcLogin
        '
        Me.UcLogin.ConnectionString = "server=ServerName\InstanceName;database=Databasename;user id=sa;password=pass;min" & _
        " pool size=1; max pool size=100 "
        Me.UcLogin.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.UcLogin.Location = New System.Drawing.Point(0, 0)
        Me.UcLogin.Name = "UcLogin"
        Me.UcLogin.SelectionMode = BLoginControl.UCLoginControl.QueryType.StoredProcedure
        Me.UcLogin.SelectQuery = ""
        Me.UcLogin.Size = New System.Drawing.Size(312, 136)
        Me.UcLogin.StoredProcedureName = "SP_ValidateLogin"
        Me.UcLogin.TabIndex = 0
        Me.UcLogin.TableName = "TBLUserTable"
        Me.UcLogin.UserIdColumnName = ""
        Me.UcLogin.UserIdParameter = "@Userid"
        Me.UcLogin.UserPasswordColumnName = ""
        Me.UcLogin.UserPasswordParameter = "@UserPassword"
        '
        'FrmLogin
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(304, 133)
        Me.Controls.Add(Me.UcLogin)
        Me.Name = "FrmLogin"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Barathan's Login Form"
        Me.ResumeLayout(False)

    End Sub

#End Region

    ' Event is fired when the user exists and it will have the validated datarow so you can use this datarow for using in the application
    ' eg: User id, User Type ,.. etc.
    Private Sub UcLogin_OnUserExists(ByVal drUserInfo As System.Data.DataRow) Handles UcLogin.OnUserExists
        Try
            MessageBox.Show("Valid User", "New Market Order", MessageBoxButtons.OK, MessageBoxIcon.Information)
        Catch ex As Exception
            MessageBox.Show("Error while Validating User", "New Market Order", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub
    ' Event is fired when the user is invalid
    Private Sub UcLogin_OnUserInvalid() Handles UcLogin.OnUserInvalid
        Try
            MessageBox.Show("Invalid User", "New Market Order", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Catch ex As Exception
            MessageBox.Show("Error while Validating User", "New Market Order", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub
End Class
