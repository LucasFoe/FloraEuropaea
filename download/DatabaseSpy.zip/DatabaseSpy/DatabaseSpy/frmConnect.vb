Imports System.Collections
Imports System.IO
Imports System.Runtime.Serialization.Formatters.Binary
Imports System.Runtime.Serialization


Public Class frmConnect

#Region "Declarations"

    Private mCurrentDataModel As String
    Private mCurrentDatabaseType As String
    Private mConnectionString As String
    Private mProviderString As String
    Private mServerName As String
    Private mInitialCatalog As String
    Private mServerPort As String
    Private mDatabaseName As String
    Private mUserID As String
    Private mPassword As String

#End Region

    Private Sub btnOracleOK_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnOracleOK.Click

        mCurrentDataModel = "MyOracle"
        mCurrentDatabaseType = "Oracle"

        mProviderString = txtOracleProvider.Text
        mPassword = txtOraclePassword.Text
        mUserID = txtOracleUserID.Text
        mServerName = txtOracleDBname.Text

        mConnectionString = "Provider=" & mProviderString & _
                            ";Password=" & mPassword & _
                            ";User ID=" & mUserID & _
                            ";Data Source=" & mServerName

        'Test Connection
        Dim cn As ADODB.Connection
        cn = New ADODB.Connection
        cn.CursorLocation = ADODB.CursorLocationEnum.adUseClient

        Try

            cn.Open(mConnectionString)
            cn.Close()
            cn = Nothing

        Catch ex As Exception

            MessageBox.Show(ex.Message.ToString(), "Application Settings Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)

        End Try

        cn = Nothing

        'set app setting global variables
        AppVars.gCurrentDataModel = mCurrentDataModel
        AppVars.gCurrentDatabaseType = mCurrentDatabaseType
        AppVars.gConnectionString = mConnectionString
        AppVars.gProviderString = mProviderString
        AppVars.gServerName = mServerName
        AppVars.gUserID = mUserID
        AppVars.gPassword = mPassword

        'create hashtable to hold settings
        Dim ht As New Hashtable
        ht.Add("CurrentDataModel", gCurrentDataModel)
        ht.Add("CurrentDatabaseType", gCurrentDatabaseType)
        ht.Add("ConnectionString", gConnectionString)
        ht.Add("ProviderString", gProviderString)
        ht.Add("ServerName", gServerName)
        ht.Add("UserID", gUserID)
        ht.Add("Password", gPassword)

        'serialize data
        SerializeAppVars(ht)

        'cache view names
        StoreViewNames()

        Me.Dispose()

    End Sub



    Public Sub StoreViewNames()

        Dim SchemaTable As DataTable
        Dim arrViews() As String = Nothing
        Dim arrTables() As String = Nothing

        If AppVars.gConnectionString <> "" Then

            'Connect to the database
            Dim conn As New System.Data.OleDb.OleDbConnection(AppVars.gConnectionString)

            Try
                conn.Open()
                'get view names
                SchemaTable = conn.GetOleDbSchemaTable(System.Data.OleDb.OleDbSchemaGuid.Tables, New Object() {Nothing, Nothing, Nothing, Nothing})
                Dim int As Integer
                Dim incr As Integer = 0

                For int = 0 To SchemaTable.Rows.Count - 1

                    If SchemaTable.Rows(int)!TABLE_TYPE.ToString = "TABLE" Then

                        Dim strTempTableName As String = SchemaTable.Rows(int)!TABLE_NAME.ToString()
                        ReDim Preserve arrTables(incr + 1)
                        arrTables(incr) = strTempTableName
                        incr = incr + 1

                    End If

                Next

                For int = 0 To SchemaTable.Rows.Count - 1

                    If SchemaTable.Rows(int)!TABLE_TYPE.ToString = "VIEW" Then

                        Dim strTempViewName As String = SchemaTable.Rows(int)!TABLE_NAME.ToString()
                        ReDim Preserve arrViews(incr + 1)
                        arrViews(incr) = strTempViewName
                        incr = incr + 1

                    End If

                Next

            Catch ex As Exception

                MessageBox.Show(ex.Message.ToString(), "Application Settings Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)

            Finally

                conn.Close()
                conn = Nothing

            End Try

            AppVars.gCurrentViews = arrViews
            AppVars.gCurrentTables = arrTables

        End If

    End Sub



    Private Sub SerializeAppVars(ByVal ht As Hashtable)

        Dim strPath As String
        strPath = Application.StartupPath & "\appset.con"

        Dim fs As New FileStream(strPath, FileMode.OpenOrCreate)
        Dim formatter As New BinaryFormatter

        Try

            formatter.Serialize(fs, ht)
            fs.Close()

        Catch ex As SerializationException

            MessageBox.Show(ex.Message, "Application Settings Serialization Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)

        End Try

    End Sub


    Private Sub btnOracleTest_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnOracleTest.Click

        mProviderString = txtOracleProvider.Text
        mPassword = txtOraclePassword.Text
        mUserID = txtOracleUserID.Text
        mServerName = txtOracleDBname.Text

        mConnectionString = "Provider=" & mProviderString & _
                            ";Password=" & mPassword & _
                            ";User ID=" & mUserID & _
                            ";Data Source=" & mServerName

        'Test Connection
        Dim cn As ADODB.Connection
        cn = New ADODB.Connection
        cn.CursorLocation = ADODB.CursorLocationEnum.adUseClient

        Try
            cn.Open(mConnectionString)
            cn.Close()
            cn = Nothing
            MessageBox.Show("Connection attempt successful, the database connection information provided has been successfully used to connect to the database.", "Connection Successful", MessageBoxButtons.OK, MessageBoxIcon.Information)

        Catch ex As Exception

            MessageBox.Show("Connection attempt failed.", "Unable to Connect", MessageBoxButtons.OK, MessageBoxIcon.Error)

        End Try

        cn = Nothing

    End Sub



    Private Sub btnOracleCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnOracleCancel.Click

        Me.Dispose()

    End Sub


    Private Sub btnBrowse_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnBrowse.Click

        Dim openFile As New System.Windows.Forms.OpenFileDialog
        openFile.Title = "MS Access Database"
        openFile.DefaultExt = "mdb"
        openFile.Filter = "Access Database (*.mdb)|*.mdb"
        openFile.ShowDialog()
        txtAccessDBname.Text = openFile.FileName

    End Sub


    Private Sub btnAccessOK_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAccessOK.Click

        mCurrentDataModel = "MyAccess"
        mCurrentDatabaseType = "Access"

        mProviderString = txtAccessProvider.Text
        mPassword = txtAccessPassword.Text
        mUserID = txtAccessUserID.Text
        mServerName = txtAccessDBname.Text

        mConnectionString = "Provider=" & mProviderString & _
                            ";Password=" & mPassword & _
                            ";User ID=" & mUserID & _
                            ";Data Source=" & mServerName

        'Test Connection
        Dim cn As ADODB.Connection
        cn = New ADODB.Connection
        cn.CursorLocation = ADODB.CursorLocationEnum.adUseClient

        Try

            cn.Open(mConnectionString)
            cn.Close()
            cn = Nothing

        Catch ex As Exception

            MessageBox.Show("Connection failed", "MS Access Connection", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)

        End Try

        cn = Nothing

        'set app setting global variables
        AppVars.gCurrentDataModel = mCurrentDataModel
        AppVars.gCurrentDatabaseType = mCurrentDatabaseType
        AppVars.gConnectionString = mConnectionString
        AppVars.gProviderString = mProviderString
        AppVars.gServerName = mServerName
        AppVars.gUserID = mUserID
        AppVars.gPassword = mPassword

        'create hashtable to hold settings
        Dim ht As New Hashtable
        ht.Add("CurrentDataModel", gCurrentDataModel)
        ht.Add("CurrentDatabaseType", gCurrentDatabaseType)
        ht.Add("ConnectionString", gConnectionString)
        ht.Add("ProviderString", gProviderString)
        ht.Add("ServerName", gServerName)
        ht.Add("UserID", gUserID)
        ht.Add("Password", gPassword)

        'serialize data
        SerializeAppVars(ht)

        'cache view names
        StoreViewNames()

        Me.Dispose()

    End Sub



    Private Sub btnAccessTest_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAccessTest.Click

        mProviderString = txtAccessProvider.Text
        mPassword = txtAccessPassword.Text
        mUserID = txtAccessUserID.Text
        mServerName = txtAccessDBname.Text

        mConnectionString = "Provider=" & mProviderString & _
                            ";Password=" & mPassword & _
                            ";User ID=" & mUserID & _
                            ";Data Source=" & mServerName

        'Test Connection
        Dim cn As ADODB.Connection
        cn = New ADODB.Connection
        cn.CursorLocation = ADODB.CursorLocationEnum.adUseClient

        Try

            cn.Open(mConnectionString)
            cn.Close()
            cn = Nothing
            MessageBox.Show("Connection attempt succeeded.", "MS Access Test", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)

        Catch ex As Exception

            MessageBox.Show("Connection attempt failed.", "MS Access Test", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)

        End Try

        cn = Nothing

    End Sub



    Private Sub btnAccessCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAccessCancel.Click

        Me.Dispose()

    End Sub



    Private Sub btnSqlServerOK_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSqlServerOK.Click

        mCurrentDataModel = "MySQLServer"
        mCurrentDatabaseType = "SqlServer"

        mProviderString = txtSqlServerProvider.Text
        mPassword = txtSqlServerPassword.Text
        mUserID = txtSqlServerUserID.Text
        mServerName = txtSqlServerDBName.Text
        mInitialCatalog = txtSqlServerInitialCat.Text

        mConnectionString = "Provider=" & mProviderString & _
                            ";Password=" & mPassword & _
                            ";User ID=" & mUserID & _
                            ";Data Source=" & mServerName & _
                            ";Initial Catalog=" & mInitialCatalog

        'Test Connection
        Dim cn As ADODB.Connection
        cn = New ADODB.Connection
        cn.CursorLocation = ADODB.CursorLocationEnum.adUseClient

        Try

            cn.Open(mConnectionString)
            cn.Close()
            cn = Nothing
 
        Catch ex As Exception

            MessageBox.Show("Connection Failure", "SQL Server Connection", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)

        End Try

        cn = Nothing


        'set app setting global variables
        AppVars.gCurrentDataModel = mCurrentDataModel
        AppVars.gCurrentDatabaseType = mCurrentDatabaseType
        AppVars.gConnectionString = mConnectionString
        AppVars.gProviderString = mProviderString
        AppVars.gInitialCatalog = mInitialCatalog
        AppVars.gServerName = mServerName
        AppVars.gUserID = mUserID
        AppVars.gPassword = mPassword

        'create hashtable to hold settings
        Dim ht As New Hashtable
        ht.Add("CurrentDataModel", gCurrentDataModel)
        ht.Add("CurrentDatabaseType", gCurrentDatabaseType)
        ht.Add("ConnectionString", gConnectionString)
        ht.Add("ProviderString", gProviderString)
        ht.Add("InitialCatalog", gInitialCatalog)
        ht.Add("ServerName", gServerName)
        ht.Add("UserID", gUserID)
        ht.Add("Password", gPassword)

        'serialize data
        SerializeAppVars(ht)

        'cache view names
        StoreViewNames()

        Me.Dispose()

    End Sub


    Private Sub btnSqlServerTest_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSqlServerTest.Click

        mProviderString = txtSqlServerProvider.Text
        mPassword = txtSqlServerPassword.Text
        mUserID = txtSqlServerUserID.Text
        mServerName = txtSqlServerDBName.Text
        mInitialCatalog = txtSqlServerInitialCat.Text

        mConnectionString = "Provider=" & mProviderString & _
                            ";Password=" & mPassword & _
                            ";User ID=" & mUserID & _
                            ";Data Source=" & mServerName & _
                            ";Initial Catalog=" & mInitialCatalog

        'Test Connection
        Dim cn As ADODB.Connection
        cn = New ADODB.Connection
        cn.CursorLocation = ADODB.CursorLocationEnum.adUseClient

        Try

            cn.Open(mConnectionString)
            cn.Close()
            cn = Nothing
            MessageBox.Show("Connection Attempt Successful.", "SQL Server Test", MessageBoxButtons.OK, MessageBoxIcon.Information)

        Catch ex As Exception

            MessageBox.Show("Connection Attempt Failed.", "SQL Server Test", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)

        End Try

        cn = Nothing

    End Sub


    Private Sub btnSQLserverCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSQLserverCancel.Click

        Me.Dispose()

    End Sub



End Class