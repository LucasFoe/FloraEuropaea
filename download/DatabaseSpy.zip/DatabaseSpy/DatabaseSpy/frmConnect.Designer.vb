<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmConnect
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmConnect))
        Me.TabControl1 = New System.Windows.Forms.TabControl
        Me.TabPage1 = New System.Windows.Forms.TabPage
        Me.gbxOracle1 = New System.Windows.Forms.GroupBox
        Me.txtOracleProvider = New System.Windows.Forms.TextBox
        Me.lblOracleProvider = New System.Windows.Forms.Label
        Me.gbxOracle4 = New System.Windows.Forms.GroupBox
        Me.btnOracleCancel = New System.Windows.Forms.Button
        Me.btnOracleTest = New System.Windows.Forms.Button
        Me.btnOracleOK = New System.Windows.Forms.Button
        Me.gbxOracle3 = New System.Windows.Forms.GroupBox
        Me.txtOraclePassword = New System.Windows.Forms.TextBox
        Me.txtOracleUserID = New System.Windows.Forms.TextBox
        Me.lblOraclePassword = New System.Windows.Forms.Label
        Me.lblOracleUserID = New System.Windows.Forms.Label
        Me.gbxOracle2 = New System.Windows.Forms.GroupBox
        Me.txtOracleDBname = New System.Windows.Forms.TextBox
        Me.lblOracleDBname = New System.Windows.Forms.Label
        Me.TabPage3 = New System.Windows.Forms.TabPage
        Me.gbxAccess4 = New System.Windows.Forms.GroupBox
        Me.btnAccessCancel = New System.Windows.Forms.Button
        Me.btnAccessTest = New System.Windows.Forms.Button
        Me.btnAccessOK = New System.Windows.Forms.Button
        Me.gbxAccess3 = New System.Windows.Forms.GroupBox
        Me.txtAccessPassword = New System.Windows.Forms.TextBox
        Me.txtAccessUserID = New System.Windows.Forms.TextBox
        Me.lblAccessPassword = New System.Windows.Forms.Label
        Me.lblAccessUserID = New System.Windows.Forms.Label
        Me.gbxAccess2 = New System.Windows.Forms.GroupBox
        Me.btnBrowse = New System.Windows.Forms.Button
        Me.txtAccessDBname = New System.Windows.Forms.TextBox
        Me.lblAccessDBname = New System.Windows.Forms.Label
        Me.gbxAccess1 = New System.Windows.Forms.GroupBox
        Me.txtAccessProvider = New System.Windows.Forms.TextBox
        Me.lblAccessProvider = New System.Windows.Forms.Label
        Me.TabPage2 = New System.Windows.Forms.TabPage
        Me.gbxSqlServer3 = New System.Windows.Forms.GroupBox
        Me.txtSqlServerInitialCat = New System.Windows.Forms.TextBox
        Me.lblSqlServerInitialCat = New System.Windows.Forms.Label
        Me.gbxSqlServer1 = New System.Windows.Forms.GroupBox
        Me.txtSqlServerProvider = New System.Windows.Forms.TextBox
        Me.lblSqlServerProvider = New System.Windows.Forms.Label
        Me.gbxSqlServer5 = New System.Windows.Forms.GroupBox
        Me.btnSQLserverCancel = New System.Windows.Forms.Button
        Me.btnSqlServerTest = New System.Windows.Forms.Button
        Me.btnSqlServerOK = New System.Windows.Forms.Button
        Me.gbxSqlServer4 = New System.Windows.Forms.GroupBox
        Me.txtSqlServerPassword = New System.Windows.Forms.TextBox
        Me.txtSqlServerUserID = New System.Windows.Forms.TextBox
        Me.lblSqlServerPassword = New System.Windows.Forms.Label
        Me.lblSqlServerUserID = New System.Windows.Forms.Label
        Me.gbxSqlServer2 = New System.Windows.Forms.GroupBox
        Me.txtSqlServerDBName = New System.Windows.Forms.TextBox
        Me.lblSqlServerName = New System.Windows.Forms.Label
        Me.TabControl1.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        Me.gbxOracle1.SuspendLayout()
        Me.gbxOracle4.SuspendLayout()
        Me.gbxOracle3.SuspendLayout()
        Me.gbxOracle2.SuspendLayout()
        Me.TabPage3.SuspendLayout()
        Me.gbxAccess4.SuspendLayout()
        Me.gbxAccess3.SuspendLayout()
        Me.gbxAccess2.SuspendLayout()
        Me.gbxAccess1.SuspendLayout()
        Me.TabPage2.SuspendLayout()
        Me.gbxSqlServer3.SuspendLayout()
        Me.gbxSqlServer1.SuspendLayout()
        Me.gbxSqlServer5.SuspendLayout()
        Me.gbxSqlServer4.SuspendLayout()
        Me.gbxSqlServer2.SuspendLayout()
        Me.SuspendLayout()
        '
        'TabControl1
        '
        Me.TabControl1.Controls.Add(Me.TabPage1)
        Me.TabControl1.Controls.Add(Me.TabPage3)
        Me.TabControl1.Controls.Add(Me.TabPage2)
        Me.TabControl1.Location = New System.Drawing.Point(12, 12)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(360, 464)
        Me.TabControl1.TabIndex = 7
        '
        'TabPage1
        '
        Me.TabPage1.Controls.Add(Me.gbxOracle1)
        Me.TabPage1.Controls.Add(Me.gbxOracle4)
        Me.TabPage1.Controls.Add(Me.gbxOracle3)
        Me.TabPage1.Controls.Add(Me.gbxOracle2)
        Me.TabPage1.Location = New System.Drawing.Point(4, 22)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Size = New System.Drawing.Size(352, 438)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "Oracle"
        Me.TabPage1.UseVisualStyleBackColor = True
        '
        'gbxOracle1
        '
        Me.gbxOracle1.Controls.Add(Me.txtOracleProvider)
        Me.gbxOracle1.Controls.Add(Me.lblOracleProvider)
        Me.gbxOracle1.Location = New System.Drawing.Point(8, 16)
        Me.gbxOracle1.Name = "gbxOracle1"
        Me.gbxOracle1.Size = New System.Drawing.Size(336, 80)
        Me.gbxOracle1.TabIndex = 8
        Me.gbxOracle1.TabStop = False
        Me.gbxOracle1.Text = "Oracle Data Provider"
        '
        'txtOracleProvider
        '
        Me.txtOracleProvider.Location = New System.Drawing.Point(40, 48)
        Me.txtOracleProvider.Name = "txtOracleProvider"
        Me.txtOracleProvider.Size = New System.Drawing.Size(248, 20)
        Me.txtOracleProvider.TabIndex = 5
        Me.txtOracleProvider.Text = "OraOLEDB.Oracle"
        '
        'lblOracleProvider
        '
        Me.lblOracleProvider.Location = New System.Drawing.Point(24, 24)
        Me.lblOracleProvider.Name = "lblOracleProvider"
        Me.lblOracleProvider.Size = New System.Drawing.Size(96, 16)
        Me.lblOracleProvider.TabIndex = 4
        Me.lblOracleProvider.Text = "Provider Name: "
        '
        'gbxOracle4
        '
        Me.gbxOracle4.Controls.Add(Me.btnOracleCancel)
        Me.gbxOracle4.Controls.Add(Me.btnOracleTest)
        Me.gbxOracle4.Controls.Add(Me.btnOracleOK)
        Me.gbxOracle4.Location = New System.Drawing.Point(8, 304)
        Me.gbxOracle4.Name = "gbxOracle4"
        Me.gbxOracle4.Size = New System.Drawing.Size(336, 48)
        Me.gbxOracle4.TabIndex = 7
        Me.gbxOracle4.TabStop = False
        '
        'btnOracleCancel
        '
        Me.btnOracleCancel.Location = New System.Drawing.Point(16, 16)
        Me.btnOracleCancel.Name = "btnOracleCancel"
        Me.btnOracleCancel.Size = New System.Drawing.Size(80, 23)
        Me.btnOracleCancel.TabIndex = 2
        Me.btnOracleCancel.Text = "Cancel"
        '
        'btnOracleTest
        '
        Me.btnOracleTest.Location = New System.Drawing.Point(126, 16)
        Me.btnOracleTest.Name = "btnOracleTest"
        Me.btnOracleTest.Size = New System.Drawing.Size(75, 23)
        Me.btnOracleTest.TabIndex = 1
        Me.btnOracleTest.Text = "Test"
        '
        'btnOracleOK
        '
        Me.btnOracleOK.Location = New System.Drawing.Point(231, 16)
        Me.btnOracleOK.Name = "btnOracleOK"
        Me.btnOracleOK.Size = New System.Drawing.Size(75, 23)
        Me.btnOracleOK.TabIndex = 0
        Me.btnOracleOK.Text = "OK"
        '
        'gbxOracle3
        '
        Me.gbxOracle3.Controls.Add(Me.txtOraclePassword)
        Me.gbxOracle3.Controls.Add(Me.txtOracleUserID)
        Me.gbxOracle3.Controls.Add(Me.lblOraclePassword)
        Me.gbxOracle3.Controls.Add(Me.lblOracleUserID)
        Me.gbxOracle3.Location = New System.Drawing.Point(8, 192)
        Me.gbxOracle3.Name = "gbxOracle3"
        Me.gbxOracle3.Size = New System.Drawing.Size(336, 104)
        Me.gbxOracle3.TabIndex = 6
        Me.gbxOracle3.TabStop = False
        Me.gbxOracle3.Text = "User Credentials"
        '
        'txtOraclePassword
        '
        Me.txtOraclePassword.Location = New System.Drawing.Point(88, 64)
        Me.txtOraclePassword.Name = "txtOraclePassword"
        Me.txtOraclePassword.PasswordChar = Global.Microsoft.VisualBasic.ChrW(42)
        Me.txtOraclePassword.Size = New System.Drawing.Size(200, 20)
        Me.txtOraclePassword.TabIndex = 3
        '
        'txtOracleUserID
        '
        Me.txtOracleUserID.Location = New System.Drawing.Point(88, 32)
        Me.txtOracleUserID.Name = "txtOracleUserID"
        Me.txtOracleUserID.Size = New System.Drawing.Size(200, 20)
        Me.txtOracleUserID.TabIndex = 2
        '
        'lblOraclePassword
        '
        Me.lblOraclePassword.Location = New System.Drawing.Point(16, 61)
        Me.lblOraclePassword.Name = "lblOraclePassword"
        Me.lblOraclePassword.Size = New System.Drawing.Size(64, 23)
        Me.lblOraclePassword.TabIndex = 1
        Me.lblOraclePassword.Text = "Password:"
        Me.lblOraclePassword.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblOracleUserID
        '
        Me.lblOracleUserID.Location = New System.Drawing.Point(16, 32)
        Me.lblOracleUserID.Name = "lblOracleUserID"
        Me.lblOracleUserID.Size = New System.Drawing.Size(64, 23)
        Me.lblOracleUserID.TabIndex = 0
        Me.lblOracleUserID.Text = "User ID:"
        Me.lblOracleUserID.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'gbxOracle2
        '
        Me.gbxOracle2.Controls.Add(Me.txtOracleDBname)
        Me.gbxOracle2.Controls.Add(Me.lblOracleDBname)
        Me.gbxOracle2.Location = New System.Drawing.Point(8, 104)
        Me.gbxOracle2.Name = "gbxOracle2"
        Me.gbxOracle2.Size = New System.Drawing.Size(336, 80)
        Me.gbxOracle2.TabIndex = 5
        Me.gbxOracle2.TabStop = False
        Me.gbxOracle2.Text = "Database"
        '
        'txtOracleDBname
        '
        Me.txtOracleDBname.Location = New System.Drawing.Point(40, 40)
        Me.txtOracleDBname.Name = "txtOracleDBname"
        Me.txtOracleDBname.Size = New System.Drawing.Size(248, 20)
        Me.txtOracleDBname.TabIndex = 3
        '
        'lblOracleDBname
        '
        Me.lblOracleDBname.Location = New System.Drawing.Point(24, 24)
        Me.lblOracleDBname.Name = "lblOracleDBname"
        Me.lblOracleDBname.Size = New System.Drawing.Size(104, 16)
        Me.lblOracleDBname.TabIndex = 0
        Me.lblOracleDBname.Text = "Database Name: "
        '
        'TabPage3
        '
        Me.TabPage3.Controls.Add(Me.gbxAccess4)
        Me.TabPage3.Controls.Add(Me.gbxAccess3)
        Me.TabPage3.Controls.Add(Me.gbxAccess2)
        Me.TabPage3.Controls.Add(Me.gbxAccess1)
        Me.TabPage3.Location = New System.Drawing.Point(4, 22)
        Me.TabPage3.Name = "TabPage3"
        Me.TabPage3.Size = New System.Drawing.Size(352, 438)
        Me.TabPage3.TabIndex = 2
        Me.TabPage3.Text = "Access"
        Me.TabPage3.UseVisualStyleBackColor = True
        Me.TabPage3.Visible = False
        '
        'gbxAccess4
        '
        Me.gbxAccess4.Controls.Add(Me.btnAccessCancel)
        Me.gbxAccess4.Controls.Add(Me.btnAccessTest)
        Me.gbxAccess4.Controls.Add(Me.btnAccessOK)
        Me.gbxAccess4.Location = New System.Drawing.Point(8, 304)
        Me.gbxAccess4.Name = "gbxAccess4"
        Me.gbxAccess4.Size = New System.Drawing.Size(336, 48)
        Me.gbxAccess4.TabIndex = 20
        Me.gbxAccess4.TabStop = False
        '
        'btnAccessCancel
        '
        Me.btnAccessCancel.Location = New System.Drawing.Point(16, 16)
        Me.btnAccessCancel.Name = "btnAccessCancel"
        Me.btnAccessCancel.Size = New System.Drawing.Size(80, 23)
        Me.btnAccessCancel.TabIndex = 2
        Me.btnAccessCancel.Text = "Cancel"
        '
        'btnAccessTest
        '
        Me.btnAccessTest.Location = New System.Drawing.Point(126, 16)
        Me.btnAccessTest.Name = "btnAccessTest"
        Me.btnAccessTest.Size = New System.Drawing.Size(75, 23)
        Me.btnAccessTest.TabIndex = 1
        Me.btnAccessTest.Text = "Test"
        '
        'btnAccessOK
        '
        Me.btnAccessOK.Location = New System.Drawing.Point(231, 16)
        Me.btnAccessOK.Name = "btnAccessOK"
        Me.btnAccessOK.Size = New System.Drawing.Size(75, 23)
        Me.btnAccessOK.TabIndex = 0
        Me.btnAccessOK.Text = "OK"
        '
        'gbxAccess3
        '
        Me.gbxAccess3.Controls.Add(Me.txtAccessPassword)
        Me.gbxAccess3.Controls.Add(Me.txtAccessUserID)
        Me.gbxAccess3.Controls.Add(Me.lblAccessPassword)
        Me.gbxAccess3.Controls.Add(Me.lblAccessUserID)
        Me.gbxAccess3.Location = New System.Drawing.Point(8, 192)
        Me.gbxAccess3.Name = "gbxAccess3"
        Me.gbxAccess3.Size = New System.Drawing.Size(336, 104)
        Me.gbxAccess3.TabIndex = 19
        Me.gbxAccess3.TabStop = False
        Me.gbxAccess3.Text = "User Credentials"
        '
        'txtAccessPassword
        '
        Me.txtAccessPassword.Location = New System.Drawing.Point(88, 64)
        Me.txtAccessPassword.Name = "txtAccessPassword"
        Me.txtAccessPassword.PasswordChar = Global.Microsoft.VisualBasic.ChrW(42)
        Me.txtAccessPassword.Size = New System.Drawing.Size(200, 20)
        Me.txtAccessPassword.TabIndex = 3
        '
        'txtAccessUserID
        '
        Me.txtAccessUserID.Location = New System.Drawing.Point(88, 32)
        Me.txtAccessUserID.Name = "txtAccessUserID"
        Me.txtAccessUserID.Size = New System.Drawing.Size(200, 20)
        Me.txtAccessUserID.TabIndex = 2
        '
        'lblAccessPassword
        '
        Me.lblAccessPassword.Location = New System.Drawing.Point(16, 61)
        Me.lblAccessPassword.Name = "lblAccessPassword"
        Me.lblAccessPassword.Size = New System.Drawing.Size(64, 23)
        Me.lblAccessPassword.TabIndex = 1
        Me.lblAccessPassword.Text = "Password:"
        Me.lblAccessPassword.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblAccessUserID
        '
        Me.lblAccessUserID.Location = New System.Drawing.Point(16, 32)
        Me.lblAccessUserID.Name = "lblAccessUserID"
        Me.lblAccessUserID.Size = New System.Drawing.Size(64, 23)
        Me.lblAccessUserID.TabIndex = 0
        Me.lblAccessUserID.Text = "User ID:"
        Me.lblAccessUserID.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'gbxAccess2
        '
        Me.gbxAccess2.Controls.Add(Me.btnBrowse)
        Me.gbxAccess2.Controls.Add(Me.txtAccessDBname)
        Me.gbxAccess2.Controls.Add(Me.lblAccessDBname)
        Me.gbxAccess2.Location = New System.Drawing.Point(8, 104)
        Me.gbxAccess2.Name = "gbxAccess2"
        Me.gbxAccess2.Size = New System.Drawing.Size(336, 80)
        Me.gbxAccess2.TabIndex = 18
        Me.gbxAccess2.TabStop = False
        Me.gbxAccess2.Text = "Database"
        '
        'btnBrowse
        '
        Me.btnBrowse.Location = New System.Drawing.Point(256, 40)
        Me.btnBrowse.Name = "btnBrowse"
        Me.btnBrowse.Size = New System.Drawing.Size(64, 23)
        Me.btnBrowse.TabIndex = 4
        Me.btnBrowse.Text = "Browse"
        '
        'txtAccessDBname
        '
        Me.txtAccessDBname.Location = New System.Drawing.Point(40, 40)
        Me.txtAccessDBname.Name = "txtAccessDBname"
        Me.txtAccessDBname.Size = New System.Drawing.Size(208, 20)
        Me.txtAccessDBname.TabIndex = 3
        '
        'lblAccessDBname
        '
        Me.lblAccessDBname.Location = New System.Drawing.Point(24, 24)
        Me.lblAccessDBname.Name = "lblAccessDBname"
        Me.lblAccessDBname.Size = New System.Drawing.Size(104, 16)
        Me.lblAccessDBname.TabIndex = 0
        Me.lblAccessDBname.Text = "Database Name: "
        '
        'gbxAccess1
        '
        Me.gbxAccess1.Controls.Add(Me.txtAccessProvider)
        Me.gbxAccess1.Controls.Add(Me.lblAccessProvider)
        Me.gbxAccess1.Location = New System.Drawing.Point(8, 16)
        Me.gbxAccess1.Name = "gbxAccess1"
        Me.gbxAccess1.Size = New System.Drawing.Size(336, 80)
        Me.gbxAccess1.TabIndex = 17
        Me.gbxAccess1.TabStop = False
        Me.gbxAccess1.Text = "Access Data Provider"
        '
        'txtAccessProvider
        '
        Me.txtAccessProvider.Location = New System.Drawing.Point(40, 48)
        Me.txtAccessProvider.Name = "txtAccessProvider"
        Me.txtAccessProvider.Size = New System.Drawing.Size(256, 20)
        Me.txtAccessProvider.TabIndex = 6
        Me.txtAccessProvider.Text = "Microsoft.Jet.OLEDB.4.0"
        '
        'lblAccessProvider
        '
        Me.lblAccessProvider.Location = New System.Drawing.Point(24, 24)
        Me.lblAccessProvider.Name = "lblAccessProvider"
        Me.lblAccessProvider.Size = New System.Drawing.Size(96, 16)
        Me.lblAccessProvider.TabIndex = 4
        Me.lblAccessProvider.Text = "Provider Name: "
        '
        'TabPage2
        '
        Me.TabPage2.Controls.Add(Me.gbxSqlServer3)
        Me.TabPage2.Controls.Add(Me.gbxSqlServer1)
        Me.TabPage2.Controls.Add(Me.gbxSqlServer5)
        Me.TabPage2.Controls.Add(Me.gbxSqlServer4)
        Me.TabPage2.Controls.Add(Me.gbxSqlServer2)
        Me.TabPage2.Location = New System.Drawing.Point(4, 22)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Size = New System.Drawing.Size(352, 438)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "SQL Server"
        Me.TabPage2.UseVisualStyleBackColor = True
        Me.TabPage2.Visible = False
        '
        'gbxSqlServer3
        '
        Me.gbxSqlServer3.Controls.Add(Me.txtSqlServerInitialCat)
        Me.gbxSqlServer3.Controls.Add(Me.lblSqlServerInitialCat)
        Me.gbxSqlServer3.Location = New System.Drawing.Point(8, 184)
        Me.gbxSqlServer3.Name = "gbxSqlServer3"
        Me.gbxSqlServer3.Size = New System.Drawing.Size(336, 80)
        Me.gbxSqlServer3.TabIndex = 17
        Me.gbxSqlServer3.TabStop = False
        Me.gbxSqlServer3.Text = "Initial Catalog"
        '
        'txtSqlServerInitialCat
        '
        Me.txtSqlServerInitialCat.Location = New System.Drawing.Point(40, 40)
        Me.txtSqlServerInitialCat.Name = "txtSqlServerInitialCat"
        Me.txtSqlServerInitialCat.Size = New System.Drawing.Size(248, 20)
        Me.txtSqlServerInitialCat.TabIndex = 3
        '
        'lblSqlServerInitialCat
        '
        Me.lblSqlServerInitialCat.Location = New System.Drawing.Point(24, 24)
        Me.lblSqlServerInitialCat.Name = "lblSqlServerInitialCat"
        Me.lblSqlServerInitialCat.Size = New System.Drawing.Size(176, 16)
        Me.lblSqlServerInitialCat.TabIndex = 0
        Me.lblSqlServerInitialCat.Text = "SQL Server Initial Catalog"
        '
        'gbxSqlServer1
        '
        Me.gbxSqlServer1.Controls.Add(Me.txtSqlServerProvider)
        Me.gbxSqlServer1.Controls.Add(Me.lblSqlServerProvider)
        Me.gbxSqlServer1.Location = New System.Drawing.Point(8, 15)
        Me.gbxSqlServer1.Name = "gbxSqlServer1"
        Me.gbxSqlServer1.Size = New System.Drawing.Size(336, 80)
        Me.gbxSqlServer1.TabIndex = 16
        Me.gbxSqlServer1.TabStop = False
        Me.gbxSqlServer1.Text = "SQL Server Data Provider"
        '
        'txtSqlServerProvider
        '
        Me.txtSqlServerProvider.Location = New System.Drawing.Point(40, 48)
        Me.txtSqlServerProvider.Name = "txtSqlServerProvider"
        Me.txtSqlServerProvider.Size = New System.Drawing.Size(256, 20)
        Me.txtSqlServerProvider.TabIndex = 6
        Me.txtSqlServerProvider.Text = "SQLOLEDB"
        '
        'lblSqlServerProvider
        '
        Me.lblSqlServerProvider.Location = New System.Drawing.Point(24, 24)
        Me.lblSqlServerProvider.Name = "lblSqlServerProvider"
        Me.lblSqlServerProvider.Size = New System.Drawing.Size(96, 16)
        Me.lblSqlServerProvider.TabIndex = 4
        Me.lblSqlServerProvider.Text = "Provider Name: "
        '
        'gbxSqlServer5
        '
        Me.gbxSqlServer5.Controls.Add(Me.btnSQLserverCancel)
        Me.gbxSqlServer5.Controls.Add(Me.btnSqlServerTest)
        Me.gbxSqlServer5.Controls.Add(Me.btnSqlServerOK)
        Me.gbxSqlServer5.Location = New System.Drawing.Point(8, 384)
        Me.gbxSqlServer5.Name = "gbxSqlServer5"
        Me.gbxSqlServer5.Size = New System.Drawing.Size(336, 48)
        Me.gbxSqlServer5.TabIndex = 15
        Me.gbxSqlServer5.TabStop = False
        '
        'btnSQLserverCancel
        '
        Me.btnSQLserverCancel.Location = New System.Drawing.Point(16, 16)
        Me.btnSQLserverCancel.Name = "btnSQLserverCancel"
        Me.btnSQLserverCancel.Size = New System.Drawing.Size(80, 23)
        Me.btnSQLserverCancel.TabIndex = 2
        Me.btnSQLserverCancel.Text = "Cancel"
        '
        'btnSqlServerTest
        '
        Me.btnSqlServerTest.Location = New System.Drawing.Point(126, 16)
        Me.btnSqlServerTest.Name = "btnSqlServerTest"
        Me.btnSqlServerTest.Size = New System.Drawing.Size(75, 23)
        Me.btnSqlServerTest.TabIndex = 1
        Me.btnSqlServerTest.Text = "Test"
        '
        'btnSqlServerOK
        '
        Me.btnSqlServerOK.Location = New System.Drawing.Point(231, 16)
        Me.btnSqlServerOK.Name = "btnSqlServerOK"
        Me.btnSqlServerOK.Size = New System.Drawing.Size(75, 23)
        Me.btnSqlServerOK.TabIndex = 0
        Me.btnSqlServerOK.Text = "OK"
        '
        'gbxSqlServer4
        '
        Me.gbxSqlServer4.Controls.Add(Me.txtSqlServerPassword)
        Me.gbxSqlServer4.Controls.Add(Me.txtSqlServerUserID)
        Me.gbxSqlServer4.Controls.Add(Me.lblSqlServerPassword)
        Me.gbxSqlServer4.Controls.Add(Me.lblSqlServerUserID)
        Me.gbxSqlServer4.Location = New System.Drawing.Point(8, 272)
        Me.gbxSqlServer4.Name = "gbxSqlServer4"
        Me.gbxSqlServer4.Size = New System.Drawing.Size(336, 104)
        Me.gbxSqlServer4.TabIndex = 14
        Me.gbxSqlServer4.TabStop = False
        Me.gbxSqlServer4.Text = "User Credentials"
        '
        'txtSqlServerPassword
        '
        Me.txtSqlServerPassword.Location = New System.Drawing.Point(88, 64)
        Me.txtSqlServerPassword.Name = "txtSqlServerPassword"
        Me.txtSqlServerPassword.PasswordChar = Global.Microsoft.VisualBasic.ChrW(42)
        Me.txtSqlServerPassword.Size = New System.Drawing.Size(200, 20)
        Me.txtSqlServerPassword.TabIndex = 3
        '
        'txtSqlServerUserID
        '
        Me.txtSqlServerUserID.Location = New System.Drawing.Point(88, 32)
        Me.txtSqlServerUserID.Name = "txtSqlServerUserID"
        Me.txtSqlServerUserID.Size = New System.Drawing.Size(200, 20)
        Me.txtSqlServerUserID.TabIndex = 2
        '
        'lblSqlServerPassword
        '
        Me.lblSqlServerPassword.Location = New System.Drawing.Point(16, 61)
        Me.lblSqlServerPassword.Name = "lblSqlServerPassword"
        Me.lblSqlServerPassword.Size = New System.Drawing.Size(64, 23)
        Me.lblSqlServerPassword.TabIndex = 1
        Me.lblSqlServerPassword.Text = "Password:"
        Me.lblSqlServerPassword.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblSqlServerUserID
        '
        Me.lblSqlServerUserID.Location = New System.Drawing.Point(16, 32)
        Me.lblSqlServerUserID.Name = "lblSqlServerUserID"
        Me.lblSqlServerUserID.Size = New System.Drawing.Size(64, 23)
        Me.lblSqlServerUserID.TabIndex = 0
        Me.lblSqlServerUserID.Text = "User ID:"
        Me.lblSqlServerUserID.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'gbxSqlServer2
        '
        Me.gbxSqlServer2.Controls.Add(Me.txtSqlServerDBName)
        Me.gbxSqlServer2.Controls.Add(Me.lblSqlServerName)
        Me.gbxSqlServer2.Location = New System.Drawing.Point(8, 103)
        Me.gbxSqlServer2.Name = "gbxSqlServer2"
        Me.gbxSqlServer2.Size = New System.Drawing.Size(336, 80)
        Me.gbxSqlServer2.TabIndex = 13
        Me.gbxSqlServer2.TabStop = False
        Me.gbxSqlServer2.Text = "Data Source"
        '
        'txtSqlServerDBName
        '
        Me.txtSqlServerDBName.Location = New System.Drawing.Point(40, 40)
        Me.txtSqlServerDBName.Name = "txtSqlServerDBName"
        Me.txtSqlServerDBName.Size = New System.Drawing.Size(248, 20)
        Me.txtSqlServerDBName.TabIndex = 3
        '
        'lblSqlServerName
        '
        Me.lblSqlServerName.Location = New System.Drawing.Point(24, 24)
        Me.lblSqlServerName.Name = "lblSqlServerName"
        Me.lblSqlServerName.Size = New System.Drawing.Size(80, 16)
        Me.lblSqlServerName.TabIndex = 0
        Me.lblSqlServerName.Text = "Server Name: "
        '
        'frmConnect
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(379, 481)
        Me.Controls.Add(Me.TabControl1)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "frmConnect"
        Me.Text = "Connection Manger"
        Me.TabControl1.ResumeLayout(False)
        Me.TabPage1.ResumeLayout(False)
        Me.gbxOracle1.ResumeLayout(False)
        Me.gbxOracle1.PerformLayout()
        Me.gbxOracle4.ResumeLayout(False)
        Me.gbxOracle3.ResumeLayout(False)
        Me.gbxOracle3.PerformLayout()
        Me.gbxOracle2.ResumeLayout(False)
        Me.gbxOracle2.PerformLayout()
        Me.TabPage3.ResumeLayout(False)
        Me.gbxAccess4.ResumeLayout(False)
        Me.gbxAccess3.ResumeLayout(False)
        Me.gbxAccess3.PerformLayout()
        Me.gbxAccess2.ResumeLayout(False)
        Me.gbxAccess2.PerformLayout()
        Me.gbxAccess1.ResumeLayout(False)
        Me.gbxAccess1.PerformLayout()
        Me.TabPage2.ResumeLayout(False)
        Me.gbxSqlServer3.ResumeLayout(False)
        Me.gbxSqlServer3.PerformLayout()
        Me.gbxSqlServer1.ResumeLayout(False)
        Me.gbxSqlServer1.PerformLayout()
        Me.gbxSqlServer5.ResumeLayout(False)
        Me.gbxSqlServer4.ResumeLayout(False)
        Me.gbxSqlServer4.PerformLayout()
        Me.gbxSqlServer2.ResumeLayout(False)
        Me.gbxSqlServer2.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents TabControl1 As System.Windows.Forms.TabControl
    Friend WithEvents TabPage1 As System.Windows.Forms.TabPage
    Friend WithEvents gbxOracle1 As System.Windows.Forms.GroupBox
    Friend WithEvents txtOracleProvider As System.Windows.Forms.TextBox
    Friend WithEvents lblOracleProvider As System.Windows.Forms.Label
    Friend WithEvents gbxOracle4 As System.Windows.Forms.GroupBox
    Friend WithEvents btnOracleCancel As System.Windows.Forms.Button
    Friend WithEvents btnOracleTest As System.Windows.Forms.Button
    Friend WithEvents btnOracleOK As System.Windows.Forms.Button
    Friend WithEvents gbxOracle3 As System.Windows.Forms.GroupBox
    Friend WithEvents txtOraclePassword As System.Windows.Forms.TextBox
    Friend WithEvents txtOracleUserID As System.Windows.Forms.TextBox
    Friend WithEvents lblOraclePassword As System.Windows.Forms.Label
    Friend WithEvents lblOracleUserID As System.Windows.Forms.Label
    Friend WithEvents gbxOracle2 As System.Windows.Forms.GroupBox
    Friend WithEvents txtOracleDBname As System.Windows.Forms.TextBox
    Friend WithEvents lblOracleDBname As System.Windows.Forms.Label
    Friend WithEvents TabPage3 As System.Windows.Forms.TabPage
    Friend WithEvents gbxAccess4 As System.Windows.Forms.GroupBox
    Friend WithEvents btnAccessCancel As System.Windows.Forms.Button
    Friend WithEvents btnAccessTest As System.Windows.Forms.Button
    Friend WithEvents btnAccessOK As System.Windows.Forms.Button
    Friend WithEvents gbxAccess3 As System.Windows.Forms.GroupBox
    Friend WithEvents txtAccessPassword As System.Windows.Forms.TextBox
    Friend WithEvents txtAccessUserID As System.Windows.Forms.TextBox
    Friend WithEvents lblAccessPassword As System.Windows.Forms.Label
    Friend WithEvents lblAccessUserID As System.Windows.Forms.Label
    Friend WithEvents gbxAccess2 As System.Windows.Forms.GroupBox
    Friend WithEvents btnBrowse As System.Windows.Forms.Button
    Friend WithEvents txtAccessDBname As System.Windows.Forms.TextBox
    Friend WithEvents lblAccessDBname As System.Windows.Forms.Label
    Friend WithEvents gbxAccess1 As System.Windows.Forms.GroupBox
    Friend WithEvents txtAccessProvider As System.Windows.Forms.TextBox
    Friend WithEvents lblAccessProvider As System.Windows.Forms.Label
    Friend WithEvents TabPage2 As System.Windows.Forms.TabPage
    Friend WithEvents gbxSqlServer3 As System.Windows.Forms.GroupBox
    Friend WithEvents txtSqlServerInitialCat As System.Windows.Forms.TextBox
    Friend WithEvents lblSqlServerInitialCat As System.Windows.Forms.Label
    Friend WithEvents gbxSqlServer1 As System.Windows.Forms.GroupBox
    Friend WithEvents txtSqlServerProvider As System.Windows.Forms.TextBox
    Friend WithEvents lblSqlServerProvider As System.Windows.Forms.Label
    Friend WithEvents gbxSqlServer5 As System.Windows.Forms.GroupBox
    Friend WithEvents btnSQLserverCancel As System.Windows.Forms.Button
    Friend WithEvents btnSqlServerTest As System.Windows.Forms.Button
    Friend WithEvents btnSqlServerOK As System.Windows.Forms.Button
    Friend WithEvents gbxSqlServer4 As System.Windows.Forms.GroupBox
    Friend WithEvents txtSqlServerPassword As System.Windows.Forms.TextBox
    Friend WithEvents txtSqlServerUserID As System.Windows.Forms.TextBox
    Friend WithEvents lblSqlServerPassword As System.Windows.Forms.Label
    Friend WithEvents lblSqlServerUserID As System.Windows.Forms.Label
    Friend WithEvents gbxSqlServer2 As System.Windows.Forms.GroupBox
    Friend WithEvents txtSqlServerDBName As System.Windows.Forms.TextBox
    Friend WithEvents lblSqlServerName As System.Windows.Forms.Label
End Class
