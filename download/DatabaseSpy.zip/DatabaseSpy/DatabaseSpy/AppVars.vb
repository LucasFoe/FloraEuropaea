Module AppVars

    Public gCurrentDataModel As String              'current data model selected
    Public gCurrentDatabaseType As String           'type of database used for live access
    Public gConnectionString As String              'full connect string for live data access
    Public gInitialCatalog As String                'sql server initial catalog for sql server connections
    Public gProviderString As String                'provider name used for live data access
    Public gServerName As String                    'server name for live data access
    Public gUserID As String                        'its the user id used to connect to LIVE data
    Public gPassword As String                      'its the password value used to connect to LIVE data
    Public gCurrentTables() As String               'tables stored to populate table and field lists
    Public gCurrentViews() As String                'views stored to populate table and field lists

End Module
