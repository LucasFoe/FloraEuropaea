Imports System.Data
Imports System.Data.OleDb
Imports System.Data.SqlClient
Imports System.Data.SqlTypes
Imports System.Collections
Imports System.Text
Imports System.IO
Imports System.Runtime.Serialization.Formatters.Binary
Imports System.Runtime.Serialization


Public Class frmMain


#Region "Declarations"

    Public SelectedTable As String
    Private mConnectionString As String
    Private mTableSelected As Boolean

#End Region


    Private Sub OpenANewConnectionToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OpenANewConnectionToolStripMenuItem.Click

        Dim f As New frmConnect()
        f.Show()

        lstViews.Items.Clear()
        lstTables.Items.Clear()
        lstFields.Items.Clear()

    End Sub



    Private Sub OpenToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OpenToolStripMenuItem.Click

        Application.Exit()

    End Sub



    Private Sub frmMain_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        Dim mConnectionString As String = ""
        DeserializeAppSettings()

        If AppVars.gConnectionString <> "" Then
            mConnectionString = AppVars.gConnectionString.ToString()
            Me.Text = "Database - " & AppVars.gCurrentDatabaseType.ToString
        Else
            Exit Sub
        End If

        If Not Trim(mConnectionString) = Nothing Then

            Try

                OpenTablesOnStart(Trim(mConnectionString))

            Catch ex As Exception

                MessageBox.Show(ex.Message.ToString(), "Data Load Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)

            End Try

        End If

    End Sub



    Private Sub OpenTablesOnStart(ByVal strConn As String)

        Dim SchemaTable As DataTable

        'Connect to the database
        Dim conn As New System.Data.OleDb.OleDbConnection(strConn)

        Try

            conn.Open()

            'Get table and view names
            SchemaTable = conn.GetOleDbSchemaTable(System.Data.OleDb.OleDbSchemaGuid.Tables, New Object() {Nothing, Nothing, Nothing, Nothing})

            lstTables.Items.Clear()
            lstViews.Items.Clear()

            Dim int As Integer
            For int = 0 To SchemaTable.Rows.Count - 1
                If SchemaTable.Rows(int)!TABLE_TYPE.ToString = "TABLE" Then
                    lstTables.Items.Add(SchemaTable.Rows(int)!TABLE_NAME.ToString())
                End If
            Next

            For int = 0 To SchemaTable.Rows.Count - 1
                If SchemaTable.Rows(int)!TABLE_TYPE.ToString = "VIEW" Then
                    lstViews.Items.Add(SchemaTable.Rows(int)!TABLE_NAME.ToString())
                End If
            Next

        Catch ex As Exception

            MessageBox.Show(ex.Message.ToString(), "Data Load Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)

        End Try

        conn.Close()

    End Sub



    Private Sub LoadDataForCurrentConnectionToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LoadDataForCurrentConnectionToolStripMenuItem.Click

        Try

            mConnectionString = AppVars.gConnectionString.ToString()

        Catch ex As Exception

            MessageBox.Show("You need to set up a database connection before calling this method.", "No Connection", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            Exit Sub

        End Try

        Dim blnTest As Boolean
        blnTest = TestConnection()

        Me.Text = "Database - " & AppVars.gCurrentDatabaseType.ToString

        If blnTest = True Then

            If Not AppVars.gCurrentViews Is Nothing Then

                lstTables.Items.Clear()
                Dim intCnt As Integer

                For intCnt = 0 To AppVars.gCurrentViews.Length - 1
                    If AppVars.gCurrentViews(intCnt) <> Nothing Then
                        lstViews.Items.Add(AppVars.gCurrentViews(intCnt).ToString())
                    End If
                Next

                For intCnt = 0 To AppVars.gCurrentTables.Length - 1
                    If AppVars.gCurrentTables(intCnt) <> Nothing Then
                        lstTables.Items.Add(AppVars.gCurrentTables(intCnt).ToString())
                    End If
                Next

            Else

                Me.OpenTablesOnStart(mConnectionString)

            End If

        Else

            MessageBox.Show("Error loading data from the current connection.", "Data Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)

        End If

    End Sub



    Private Function TestConnection() As Boolean

        Dim cn As ADODB.Connection

        cn = New ADODB.Connection
        cn.CursorLocation = ADODB.CursorLocationEnum.adUseClient

        Try

            cn.Open(mConnectionString)

        Catch ex As Exception

            Return False

        End Try

        Return True

    End Function



    Private Sub lstTables_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lstTables.SelectedIndexChanged

        mTableSelected = True

        Dim tblName As String
        tblName = lstTables.SelectedItem.ToString()

        Dim conn As New System.Data.OleDb.OleDbConnection(mConnectionString)

        Try

            conn.Open()
            lstFields.Items.Clear()

            Dim dt_field As System.Data.DataTable = _
                        conn.GetOleDbSchemaTable( _
                            OleDb.OleDbSchemaGuid.Columns, _
                            New Object() {Nothing, Nothing, tblName})

            For Each dr_field As DataRow In dt_field.Rows
                Me.lstFields.Items.Add(dr_field("COLUMN_NAME").ToString)
            Next

        Catch ex As Exception

            MessageBox.Show(ex.StackTrace, "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)

        End Try


    End Sub



    Private Sub lstViews_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lstViews.SelectedIndexChanged

        mTableSelected = False

        Dim vuName As String
        vuName = lstViews.SelectedItem.ToString()

        Dim conn As New System.Data.OleDb.OleDbConnection(mConnectionString)

        Try

            conn.Open()
            lstFields.Items.Clear()

            Dim dt_field As System.Data.DataTable = _
                        conn.GetOleDbSchemaTable( _
                            OleDb.OleDbSchemaGuid.Columns, _
                            New Object() {Nothing, Nothing, vuName})

            For Each dr_field As DataRow In dt_field.Rows
                Me.lstFields.Items.Add(dr_field("COLUMN_NAME").ToString)
            Next

        Catch ex As Exception

            MessageBox.Show(ex.StackTrace, "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)

        End Try


    End Sub




    Private Sub DeserializeAppSettings()

        'this subroutine is called on initialization of the application; it recovers the
        'application settings stored in the appset.con binary file, deserializes them and
        'sets the application's global variables to the values stored in the appset file.

        'set the path to the appset file
        Dim strPath As String
        strPath = Application.StartupPath & "\appset.con"

        'validate the existence of the appset file, if it exists, open a file stream and
        'use a binary formatter to deserialize the binary file.  Create a hashtable to contain
        'the deserialized content and load the values into that hash.
        If File.Exists(strPath) = True Then

            Dim fs As New System.IO.FileStream(strPath, FileMode.Open)
            Dim AppSettings As Hashtable
            AppSettings = New Hashtable

            Try

                Dim formatter As New BinaryFormatter
                AppSettings = formatter.Deserialize(fs)

            Catch ex As Exception

                MessageBox.Show(ex.Message, "App Setting Deserialization Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)

            End Try

            'once the values are deserialized into the hash, read the values from the hash and
            'set the global variables to the stored values.
            If AppSettings.Count <> 0 Then

                Dim de As DictionaryEntry

                For Each de In AppSettings

                    Select Case de.Key

                        Case "CurrentDataModel"
                            gCurrentDataModel = de.Value
                        Case "CurrentDatabaseType"
                            gCurrentDatabaseType = de.Value
                        Case "ConnectionString"
                            gConnectionString = de.Value
                            Me.mConnectionString = de.Value.ToString()
                        Case "ProviderString"
                            gProviderString = de.Value
                        Case "ServerName"
                            gServerName = de.Value
                        Case "UserID"
                            gUserID = de.Value
                        Case "Password"
                            gPassword = de.Value

                    End Select

                Next

            Else

                'do nothing

            End If
        Else
            'do nothing
        End If

    End Sub


    Private Sub ViewCurrentConnectionToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ViewCurrentConnectionToolStripMenuItem.Click

        MessageBox.Show("Current Connection String: " & AppVars.gConnectionString.ToString(), "Connection String", MessageBoxButtons.OK, MessageBoxIcon.Information)

    End Sub



    Private Sub GetFieldInformationToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GetFieldInformationToolStripMenuItem.Click

        Try

            Dim cn As New OleDbConnection(mConnectionString)
            Dim sSql As String

            If mTableSelected = True Then
                sSql = "SELECT [" & Me.lstFields.SelectedItem.ToString() & "] FROM [" & lstTables.SelectedItem.ToString() & "]"
            Else
                sSql = "SELECT [" & Me.lstFields.SelectedItem.ToString() & "] FROM [" & lstViews.SelectedItem.ToString() & "]"
            End If

            Dim da As New OleDbDataAdapter(sSql, cn)
            cn.Open()

            Dim ds As New DataSet
            da.Fill(ds)

            Dim sb As New StringBuilder
            Dim tbl As DataTable = ds.Tables(0)
            Dim col As New DataColumn

            For Each col In tbl.Columns

                sb.Append("Field Characteristics:" & Environment.NewLine & Environment.NewLine)
                sb.Append("Data Type:" & Environment.NewLine)
                sb.Append(col.DataType.ToString() & Environment.NewLine & Environment.NewLine)
                sb.Append("Is Unique?" & Environment.NewLine)
                sb.Append(col.Unique.ToString() & Environment.NewLine & Environment.NewLine)
                sb.Append("Allow Nulls?" & Environment.NewLine)
                sb.Append(col.AllowDBNull.ToString() & Environment.NewLine & Environment.NewLine)
                sb.Append("Default:" & Environment.NewLine)
                sb.Append(col.DefaultValue.ToString() & Environment.NewLine & Environment.NewLine)
                sb.Append("Auto Incr:" & Environment.NewLine)
                sb.Append(col.AutoIncrement.ToString() & Environment.NewLine & Environment.NewLine)
                sb.Append("Caption:" & Environment.NewLine)
                sb.Append(col.Caption.ToString())

                MessageBox.Show(sb.ToString(), "Database Item Specification for Column: " & col.ColumnName.ToString(), MessageBoxButtons.OK, MessageBoxIcon.Information)

                Exit For

            Next

        Catch ex As Exception

            MessageBox.Show(ex.StackTrace, ex.Message, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)

        End Try

    End Sub

End Class
