<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmMain
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmMain))
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip
        Me.FileToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.OpenToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ConnectionToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.OpenANewConnectionToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ToolStripMenuItem1 = New System.Windows.Forms.ToolStripSeparator
        Me.ViewCurrentConnectionToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.LoadToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.LoadDataForCurrentConnectionToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.GroupBox1 = New System.Windows.Forms.GroupBox
        Me.lstTables = New System.Windows.Forms.ListBox
        Me.GroupBox2 = New System.Windows.Forms.GroupBox
        Me.lstViews = New System.Windows.Forms.ListBox
        Me.GroupBox3 = New System.Windows.Forms.GroupBox
        Me.lstFields = New System.Windows.Forms.ListBox
        Me.ContextMenuStrip1 = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.GetFieldInformationToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.MenuStrip1.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.ContextMenuStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.FileToolStripMenuItem, Me.ConnectionToolStripMenuItem, Me.LoadToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(552, 24)
        Me.MenuStrip1.TabIndex = 0
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'FileToolStripMenuItem
        '
        Me.FileToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.OpenToolStripMenuItem})
        Me.FileToolStripMenuItem.Name = "FileToolStripMenuItem"
        Me.FileToolStripMenuItem.Size = New System.Drawing.Size(35, 20)
        Me.FileToolStripMenuItem.Text = "&File"
        '
        'OpenToolStripMenuItem
        '
        Me.OpenToolStripMenuItem.Image = CType(resources.GetObject("OpenToolStripMenuItem.Image"), System.Drawing.Image)
        Me.OpenToolStripMenuItem.Name = "OpenToolStripMenuItem"
        Me.OpenToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.OpenToolStripMenuItem.Text = "E&xit"
        '
        'ConnectionToolStripMenuItem
        '
        Me.ConnectionToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.OpenANewConnectionToolStripMenuItem, Me.ToolStripMenuItem1, Me.ViewCurrentConnectionToolStripMenuItem})
        Me.ConnectionToolStripMenuItem.Name = "ConnectionToolStripMenuItem"
        Me.ConnectionToolStripMenuItem.Size = New System.Drawing.Size(73, 20)
        Me.ConnectionToolStripMenuItem.Text = "&Connection"
        '
        'OpenANewConnectionToolStripMenuItem
        '
        Me.OpenANewConnectionToolStripMenuItem.Image = CType(resources.GetObject("OpenANewConnectionToolStripMenuItem.Image"), System.Drawing.Image)
        Me.OpenANewConnectionToolStripMenuItem.Name = "OpenANewConnectionToolStripMenuItem"
        Me.OpenANewConnectionToolStripMenuItem.Size = New System.Drawing.Size(213, 22)
        Me.OpenANewConnectionToolStripMenuItem.Text = "O&pen a New Connection..."
        '
        'ToolStripMenuItem1
        '
        Me.ToolStripMenuItem1.Name = "ToolStripMenuItem1"
        Me.ToolStripMenuItem1.Size = New System.Drawing.Size(210, 6)
        '
        'ViewCurrentConnectionToolStripMenuItem
        '
        Me.ViewCurrentConnectionToolStripMenuItem.Image = CType(resources.GetObject("ViewCurrentConnectionToolStripMenuItem.Image"), System.Drawing.Image)
        Me.ViewCurrentConnectionToolStripMenuItem.Name = "ViewCurrentConnectionToolStripMenuItem"
        Me.ViewCurrentConnectionToolStripMenuItem.Size = New System.Drawing.Size(213, 22)
        Me.ViewCurrentConnectionToolStripMenuItem.Text = "View Current Connection"
        '
        'LoadToolStripMenuItem
        '
        Me.LoadToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.LoadDataForCurrentConnectionToolStripMenuItem})
        Me.LoadToolStripMenuItem.Name = "LoadToolStripMenuItem"
        Me.LoadToolStripMenuItem.Size = New System.Drawing.Size(42, 20)
        Me.LoadToolStripMenuItem.Text = "Load"
        '
        'LoadDataForCurrentConnectionToolStripMenuItem
        '
        Me.LoadDataForCurrentConnectionToolStripMenuItem.Image = CType(resources.GetObject("LoadDataForCurrentConnectionToolStripMenuItem.Image"), System.Drawing.Image)
        Me.LoadDataForCurrentConnectionToolStripMenuItem.Name = "LoadDataForCurrentConnectionToolStripMenuItem"
        Me.LoadDataForCurrentConnectionToolStripMenuItem.Size = New System.Drawing.Size(248, 22)
        Me.LoadDataForCurrentConnectionToolStripMenuItem.Text = "Load Data for Current Connection"
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.lstTables)
        Me.GroupBox1.Location = New System.Drawing.Point(13, 38)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(260, 147)
        Me.GroupBox1.TabIndex = 1
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Database Tables"
        '
        'lstTables
        '
        Me.lstTables.FormattingEnabled = True
        Me.lstTables.Location = New System.Drawing.Point(13, 27)
        Me.lstTables.Name = "lstTables"
        Me.lstTables.Size = New System.Drawing.Size(237, 108)
        Me.lstTables.TabIndex = 0
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.lstViews)
        Me.GroupBox2.Location = New System.Drawing.Point(13, 191)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(260, 147)
        Me.GroupBox2.TabIndex = 2
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Database Views"
        '
        'lstViews
        '
        Me.lstViews.FormattingEnabled = True
        Me.lstViews.Location = New System.Drawing.Point(11, 25)
        Me.lstViews.Name = "lstViews"
        Me.lstViews.Size = New System.Drawing.Size(237, 108)
        Me.lstViews.TabIndex = 1
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.lstFields)
        Me.GroupBox3.Location = New System.Drawing.Point(279, 38)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(260, 300)
        Me.GroupBox3.TabIndex = 3
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Selected Fields"
        '
        'lstFields
        '
        Me.lstFields.ContextMenuStrip = Me.ContextMenuStrip1
        Me.lstFields.FormattingEnabled = True
        Me.lstFields.Location = New System.Drawing.Point(12, 21)
        Me.lstFields.Name = "lstFields"
        Me.lstFields.Size = New System.Drawing.Size(236, 264)
        Me.lstFields.TabIndex = 0
        '
        'ContextMenuStrip1
        '
        Me.ContextMenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.GetFieldInformationToolStripMenuItem})
        Me.ContextMenuStrip1.Name = "ContextMenuStrip1"
        Me.ContextMenuStrip1.Size = New System.Drawing.Size(199, 26)
        '
        'GetFieldInformationToolStripMenuItem
        '
        Me.GetFieldInformationToolStripMenuItem.Image = CType(resources.GetObject("GetFieldInformationToolStripMenuItem.Image"), System.Drawing.Image)
        Me.GetFieldInformationToolStripMenuItem.Name = "GetFieldInformationToolStripMenuItem"
        Me.GetFieldInformationToolStripMenuItem.Size = New System.Drawing.Size(198, 22)
        Me.GetFieldInformationToolStripMenuItem.Text = "Get Field Information..."
        '
        'frmMain
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(552, 349)
        Me.Controls.Add(Me.GroupBox3)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.MenuStrip1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Name = "frmMain"
        Me.Text = "Database"
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox3.ResumeLayout(False)
        Me.ContextMenuStrip1.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents MenuStrip1 As System.Windows.Forms.MenuStrip
    Friend WithEvents FileToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ConnectionToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents OpenANewConnectionToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents OpenToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents lstTables As System.Windows.Forms.ListBox
    Friend WithEvents lstViews As System.Windows.Forms.ListBox
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents lstFields As System.Windows.Forms.ListBox
    Friend WithEvents LoadToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents LoadDataForCurrentConnectionToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ContextMenuStrip1 As System.Windows.Forms.ContextMenuStrip
    Friend WithEvents GetFieldInformationToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem1 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ViewCurrentConnectionToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem

End Class
